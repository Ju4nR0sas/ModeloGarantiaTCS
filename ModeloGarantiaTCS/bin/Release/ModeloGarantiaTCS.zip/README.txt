Modelo de Garantía TCS
----------------------
Para usar esta aplicación:
1️⃣ Asegúrese de tener .NET Framework 4.8 instalado.
2️⃣ Extraiga todos los archivos del ZIP en una carpeta.
3️⃣ Ejecute ModeloGarantiaTCS.exe

No borre los archivos .dll, son necesarios para el funcionamiento.